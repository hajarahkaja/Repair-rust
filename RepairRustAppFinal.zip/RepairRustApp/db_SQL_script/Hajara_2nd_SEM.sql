--Create database RepairRust
--use RepairRust

CREATE TABLE tbl_vehical(
	id int IDENTITY(1,1)  NOT NULL PRIMARY KEY,
	vehical_number varchar(10) NOT NULL,
	vehical_brand varchar(45) DEFAULT NULL,
	transmission_type varchar(45) DEFAULT NULL,
	Colour varchar(20) NOT NULL,
	year_of_manufacture int NOT NULL,
	owner_name varchar(50) DEFAULT NULL,
	owner_email varchar(50) DEFAULT NULL,
	owner_contact_no varchar(15)  DEFAULT NULL,
	owner_address varchar(100) NOT NULL
) 
CREATE TABLE tbl_employee(
	employee_id int IDENTITY(1,1) NOT NULL PRIMARY KEY,	
	employee_name varchar(50) NOT NULL,
	dob datetime DEFAULT NULL,
	address varchar(100) NULL,
	join_date datetime DEFAULT NULL,
	contact_no varchar(15) NULL	
	)
CREATE TABLE  tbl_repair_jobs (
	id int IDENTITY(1,1) NOT NULL PRIMARY KEY ,
	repair_jobs_id varchar(45) DEFAULT NULL,
	repair_name varchar(100) DEFAULT NULL,
	description varchar(200) DEFAULT NULL,
	repair_date datetime DEFAULT NULL,
	repair_by int NOT NULL,
	vehical_id int NOT NULL,
	CONSTRAINT FK_VEHICAL_ID1 FOREIGN KEY(vehical_id) REFERENCES tbl_vehical(id),
	CONSTRAINT FK_REPAIR_BY FOREIGN KEY(repair_by) REFERENCES tbl_employee(employee_id)
) 

CREATE TABLE tbl_restoration_details (
	id int IDENTITY(1,1)  NOT NULL PRIMARY KEY,
	vehical_id int NOT NULL,
	description varchar(200) DEFAULT NULL,
	date_restore datetime DEFAULT NULL,
	restored_by int NOT NULL,
	CONSTRAINT FK_VEHICAL_ID2 FOREIGN KEY(vehical_id) REFERENCES tbl_vehical(id),	
	CONSTRAINT FK_RESTORED_BY FOREIGN KEY(restored_by) REFERENCES tbl_employee(employee_id)
)
CREATE TABLE tbl_supplier(
	supplier_id int IDENTITY(1,1) NOT NULL PRIMARY KEY ,
	supplier_name varchar(50) NOT NULL,
	address varchar(100) NOT NULL,
	email varchar(50) NOT NULL,
	contact_no varchar(15)NOT NULL
)

CREATE TABLE tbl_spare_parts(
	part_id int IDENTITY(1,1) NOT NULL PRIMARY KEY,	
	spare_part_name varchar(50) NOT NULL,
	vehicle_Brand varchar(50) NOT NULL,	
	quantity int NOT NULL,
	unit_price float NOT NULL,
	supplier_id int NOT NULL,
	CONSTRAINT FK_SUPPLIER_ID FOREIGN KEY(supplier_id) REFERENCES tbl_supplier(supplier_id)
	)

CREATE TABLE  tbl_repair_jobs_parts (
	repair_id int NOT NULL,
	part_id int NOT NULL,
	quantity int NOT NULL 
	CONSTRAINT FK_repair_id FOREIGN KEY(repair_id) REFERENCES tbl_repair_jobs(id),
	CONSTRAINT FK_PART_ID FOREIGN KEY(part_id) REFERENCES tbl_spare_parts(part_id),
	CONSTRAINT PK_Person PRIMARY KEY (repair_id,part_id)
)
	CREATE TABLE Report(
	RepairID varchar(50) NOT NULL PRIMARY KEY,	
	RepairType varchar(50) NOT NULL,
	TotalRepairCharge float NOT NULL,
	TotalDisposalCharge float NOT NULL,
	TotalTowingCharge float NOT NULL,
	TotalCost float NOT NULL,
	)

	USE [RepairRust]
GO

INSERT INTO tbl_vehical
           ([vehical_number]
           ,[vehical_brand]
           ,[transmission_type]
           ,[Colour]
           ,[year_of_manufacture]
           ,[owner_name]
           ,[owner_email]
           ,[owner_contact_no]
           ,[owner_address])
     VALUES
           ('PH-8112'
           ,'SUZUKY'
           ,'Automatic'
           ,'Black'
           ,2017
           ,'ABC'
           ,'abc@gmail.com'
           ,'07511111111'
           ,'London')
GO
USE [RepairRust]
GO

INSERT INTO [dbo].[tbl_employee]
           ([employee_name]
           ,[dob]
           ,[address]
           ,[join_date]
           ,[contact_no])
     VALUES
           ('brian'
           ,'1/1/1980'
           ,'colombo'
           ,'1/1/2020'
           ,'0777777777')
GO


delete from [tbl_repair_jobs]
INSERT INTO [tbl_repair_jobs]
           (repair_jobs_id,repair_name
           ,description
           ,repair_date
           ,repair_by
           ,vehical_id)
     VALUES
           ('test2','test1','test desc',getdate() ,1,1)
GO




