/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Class;

/**
 *
 * @author hajara
 */
public class Vehical {
    int vehicalId;
    String VehicalNumber;
    String VehicalBrand;
    String VehicalModel;
    String VehicalBodyType;
    String TransmissionType;
    String Color;
    int YearOfManufacture;
    String OwnerName;
    String OwnerEmail;
    String OwnerAddress;
    String OwnerContactNo;

    public Vehical(int vehicalId,String vehicalNumber,String vehicalBrand,String vehicalModel,String vehicalBodyType,String transmissionType,String color,int yearOfManufacture,String ownerName,String ownerEmail,String ownerAddress,String OwnerContactNo)
    {
        this.vehicalId = vehicalId;
        this.VehicalNumber = vehicalNumber;
        this.VehicalBrand = vehicalBrand;
        this.VehicalModel=VehicalModel;
        this.VehicalBodyType=VehicalBodyType;
        this.TransmissionType = TransmissionType;
        this.Color=Color;
        this.YearOfManufacture=YearOfManufacture;
        this.OwnerName = OwnerName;
        this.OwnerEmail = OwnerEmail;
        this.OwnerAddress=OwnerAddress;
        this.OwnerContactNo = OwnerContactNo;
    }

    public int getvehicalId()
    {
        return vehicalId;
    }

    public String getVehicalNumber()
    {
        return VehicalNumber;
    }

    public String getVehicalBrand()
    {
        return VehicalBrand;
    }
    
    public String getVehicalModel()
    {
        return VehicalModel;
    }
    
    public String getTransmissionTypen() 
    {
        return TransmissionType;
    }
    public String getcolor()
    {
        return Color;
    }
    public int getYearOfManufacture()
    {
        return YearOfManufacture;
    }
    public String getOwnerName()
    {
        return OwnerName;
    }

    public String getOwnerEmail() 
    {
        return OwnerEmail;
    }

    public String getOwnerAddress()
    {
        return OwnerAddress;
    }
     public String getOwnerContactNo()
    {
        return OwnerContactNo;
    }

}

