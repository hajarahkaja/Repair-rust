/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Class;

import java.util.Date;
import javax.xml.crypto.Data;

/**
 *
 * @author hajara
 */
public class repairJob 
{
        int Id;
        String RepairId;
        String RepairName; 
        String Discription;
        Date RepairDate;
        int RepairBy;
        int VehicalId;

        public repairJob(int id,String repairId, String repairName, String discription, Date repairDate ,int repairBy,int vehicalId) 
        {
            this.Id = id;
            this.RepairId = repairId;
            this.RepairName = repairName;
            this.Discription = discription;
            this.RepairDate = repairDate;
            this.RepairBy = repairBy;
            this.VehicalId = vehicalId;
        }
        public int getId() 
        {
            return Id;
        }
        public String getRepairId() 
        {
            return RepairId;
        }
        public String getRepairName() 
        {
            return RepairName;
        }
        public String getDiscription() 
        {
            return Discription;
        }
        public Date getRepairDate()
        {
            return RepairDate;
        }
        public int getRepairBy()
        {
            return RepairBy;
        } 
        public int getVehicalId()
        {
            return VehicalId;
        } 
    
}
