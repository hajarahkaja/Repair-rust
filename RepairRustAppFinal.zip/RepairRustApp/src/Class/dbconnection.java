
         
package Class;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
 import javax.swing.JOptionPane;
/**
 *
 * @author hajar
 */
public class dbconnection {
    private Connection SqlCon;
    private Statement stmt;
    private ResultSet rset;
    PreparedStatement pst;
    public void getDbConnection() 
    {
        try 
        {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            this.SqlCon = DriverManager.getConnection("jdbc:sqlserver://DESKTOP-U6GFJR6\\MSSQLSERVER2020; databaseName= RepairRust; user= sa; password= Imad2018");
            //JOptionPane.showMessageDialog(null, "SQL Server Connection Successfully.");            
         }catch (Exception CnnErr){
            JOptionPane.showMessageDialog(null, "SQL Server Connection Problem");
         }
    }
    public void dbClose() {
        try {
            this.stmt.close();
            this.SqlCon.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
     public ResultSet QueryExecuteSelect(String sql) {
        try {
            this.stmt = this.SqlCon.createStatement();
            this.rset = this.stmt
                .executeQuery(sql);
            return this.rset;
        } catch (SQLException e) {
             e.printStackTrace();
             return null;
        }
    }
    public boolean QueryExecuteInsert(String sql) {
        try {
            this.stmt = this.SqlCon.createStatement();
            this.stmt.execute(sql);
        } catch (SQLException e) {
             e.printStackTrace();
             return false;
        }
        return true;
    }
    
    public void PreStatement(String sql) {
        try {
            this.pst = this.SqlCon.prepareStatement(sql);
        } catch (SQLException e) {
             e.printStackTrace();
        }
    }
     public void InsertStatementStringParam(int indx, String val) {
        try {
            this.pst.setString(indx,val);
        } catch (SQLException e) {
             e.printStackTrace();
        }
    }
     public void InsertStatementNumParam(int indx, int val) {
        try {
            this.pst.setInt(indx,val);
        } catch (SQLException e) {
             e.printStackTrace();
        }
    }
     public void InsertStatementFLOATParam(int indx, float val) {
        try {
            this.pst.setFloat(indx,val);
        } catch (SQLException e) {
             e.printStackTrace();
        }
    }
     public boolean PreStatementExecue() {
        try {
            this.pst.executeUpdate();
        } catch (SQLException e) {
             e.printStackTrace();
              return false;
        }
         return true;
    }
      public void resultSetClose() {
        try {
            this.stmt.close();
            this.rset.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
