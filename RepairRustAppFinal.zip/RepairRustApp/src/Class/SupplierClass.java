/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Class;
/**
 *
 * @author Admin
 */
public class SupplierClass {
    private int Sid;
    private String Sname,Address,Email,Phone;
    
    public SupplierClass(int Sid,String Sname,String Address,String Email,String Phone )
    {
        this.Sid=Sid;
        this.Sname=Sname;
        this.Address=Address;
        this.Email=Email;
        this.Phone=Phone;
    }

    public int getSid() {
        return Sid;
    }

    public String getSname() {
        return Sname;
    }

    public String getAddress() {
        return Address;
    }

    public String getEmail() {
        return Email;
    }

    public String getPhone() {
        return Phone;
    }
    
}
